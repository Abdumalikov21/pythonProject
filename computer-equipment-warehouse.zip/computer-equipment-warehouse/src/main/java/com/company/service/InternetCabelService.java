package com.company.service;

import com.company.dao.InternetCabelDao;
import com.company.domain.Internet_Cabel;
import com.company.dtos.AppErrorDTO;
import com.company.dtos.DataDTO;
import com.company.dtos.ResponseEntity;
import com.company.exceptions.GenericNotFoundException;

import java.util.Comparator;
import java.util.List;

public class InternetCabelService implements BaseService<Internet_Cabel> {

    private final InternetCabelDao dao = new InternetCabelDao();

    @Override
    public ResponseEntity<DataDTO<List<Internet_Cabel>>> findAll(String sort) {
        try {
            List<Internet_Cabel> internetCableList = dao.findAll();
            if (internetCableList.isEmpty()) {
                throw new GenericNotFoundException("InternetCables not found!");
            }
            switch (sort) {
                case "1" -> internetCableList.sort(Comparator.comparing(Internet_Cabel::getId));
                case "2" -> internetCableList.sort(Comparator.comparing(Internet_Cabel::getPrice));
            }
            return new ResponseEntity<>(new DataDTO<>(internetCableList), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<Internet_Cabel>> findByID(Long id) {
        try {
            Internet_Cabel internetCable = dao.findAll().stream().filter(internetCable1 ->
                    internetCable1.getId().equals(id)).findFirst().orElse(null);
            if (internetCable == null) {
                throw new GenericNotFoundException("InternetCable not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(internetCable), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<Internet_Cabel>>> findByColor(String color) {
        try {
            List<Internet_Cabel> internetCables = dao.findAll().stream().filter(internetCable ->
                    internetCable.getColor().equals(color)).toList();
            if (internetCables.isEmpty()) {
                throw new GenericNotFoundException("InternetCable not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(internetCables), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<Internet_Cabel>>> filterByPrice(Double min, Double max) {
        try {
            List<Internet_Cabel> internetCables = dao.findAll().stream().filter(internetCable ->
                    internetCable.getPrice() >= min && internetCable.getPrice() <= max).toList();
            if (internetCables.isEmpty()) {
                throw new GenericNotFoundException("InternetCable not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(internetCables), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    public ResponseEntity<DataDTO<List<Internet_Cabel>>> findByWireLess(String wireless) {
        try {
            List<Internet_Cabel> internetCableList = dao.findAll();
            if (internetCableList.isEmpty()) {
                throw new GenericNotFoundException("InternetCables not found!");
            }
            switch (wireless) {
                case "yes" -> {
                    return new ResponseEntity<>(new DataDTO<>(internetCableList.stream().filter(internetCable ->
                            internetCable.getWireless().equals(true)).toList()), 200);
                }
                case "no" -> {
                    return new ResponseEntity<>(new DataDTO<>(internetCableList.stream().filter(internetCable ->
                            internetCable.getWireless().equals(false)).toList()), 200);
                }
            }
            return new ResponseEntity<>(new DataDTO<>(internetCableList), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }
}
