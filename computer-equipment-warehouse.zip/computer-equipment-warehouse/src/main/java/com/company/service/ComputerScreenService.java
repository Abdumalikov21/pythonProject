package com.company.service;

import com.company.dao.ComputerScreenDao;
import com.company.domain.ComputerScreen;
import com.company.dtos.AppErrorDTO;
import com.company.dtos.DataDTO;
import com.company.dtos.ResponseEntity;
import com.company.exceptions.GenericNotFoundException;

import java.util.Comparator;
import java.util.List;

public class ComputerScreenService implements BaseService<ComputerScreen> {

    private final ComputerScreenDao dao = new ComputerScreenDao();

    @Override
    public ResponseEntity<DataDTO<List<ComputerScreen>>> findAll(String sort) {
        try {
            List<ComputerScreen> computerScreens = dao.findAll();
            if (computerScreens.isEmpty()) {
                throw new GenericNotFoundException("ComputerScreens not found!");
            }
            switch (sort) {
                case "1" -> computerScreens.sort(Comparator.comparing(ComputerScreen::getId));
                case "2" -> computerScreens.sort(Comparator.comparing(ComputerScreen::getPrice));
            }
            return new ResponseEntity<>(new DataDTO<>(computerScreens));
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<ComputerScreen>> findByID(Long id) {
        try {
            ComputerScreen computerScreen = dao.findAll().stream().filter(computerScreen1 ->
                    computerScreen1.getId().equals(id)).findFirst().orElse(null);
            if (computerScreen == null) {
                throw new GenericNotFoundException("ComputerScreen not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(computerScreen), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<ComputerScreen>>> findByColor(String color) {
        try {
            List<ComputerScreen> computerScreens = dao.findAll().stream().filter(computerScreen ->
                    computerScreen.getColor().equals(color)).toList();
            if (computerScreens.isEmpty()) {
                throw new GenericNotFoundException("ComputerScreen not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(computerScreens), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<ComputerScreen>>> filterByPrice(Double min, Double max) {
        try {
            List<ComputerScreen> computerScreens = dao.findAll().stream().filter(computerScreen ->
                    computerScreen.getPrice() >= min && computerScreen.getPrice() <= max).toList();
            if (computerScreens.isEmpty()) {
                throw new GenericNotFoundException("ComputerScreen not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(computerScreens), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    public ResponseEntity<DataDTO<List<ComputerScreen>>> refreshRate(Integer refreshRate) {
        try {
            List<ComputerScreen> computerScreens = dao.findAll().stream().filter(computerScreen ->
                    computerScreen.getRefreshRate().equals(refreshRate)).toList();
            if (computerScreens.isEmpty()) {
                throw new GenericNotFoundException("ComputerScreen not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(computerScreens), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    public ResponseEntity<DataDTO<List<ComputerScreen>>> displaySize(Integer displaySize) {
        try {
            List<ComputerScreen> computerScreens = dao.findAll().stream().filter(computerScreen ->
                    computerScreen.getDisplaySize().equals(displaySize)).toList();
            if (computerScreens.isEmpty()) {
                throw new GenericNotFoundException("ComputerScreen not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(computerScreens), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }
}
