package com.company.service;

import com.company.dao.ProcessorDao;
import com.company.domain.Processor;
import com.company.dtos.AppErrorDTO;
import com.company.dtos.DataDTO;
import com.company.dtos.ResponseEntity;
import com.company.exceptions.GenericNotFoundException;

import java.util.Comparator;
import java.util.List;

public class ProcessorService implements BaseService<Processor> {

    private final ProcessorDao dao = new ProcessorDao();

    @Override
    public ResponseEntity<DataDTO<List<Processor>>> findAll(String sort) {
        try {
            List<Processor> processors = dao.findAll();
            if (processors.isEmpty()) {
                throw new GenericNotFoundException("Processors not found!");
            }
            switch (sort) {
                case "1" -> processors.sort(Comparator.comparing(Processor::getId));
                case "2" -> processors.sort(Comparator.comparing(Processor::getPrice));
            }
            return new ResponseEntity<>(new DataDTO<>(processors));
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<Processor>> findByID(Long id) {
        try {
            Processor processor = dao.findAll().stream().filter(processor1 ->
                    processor1.getId().equals(id)).findFirst().orElse(null);
            if (processor == null) {
                throw new GenericNotFoundException("Processor not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(processor), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<Processor>>> findByColor(String color) {
        try {
            List<Processor> processors = dao.findAll().stream().filter(processor ->
                    processor.getColor().equals(color)).toList();
            if (processors.isEmpty()) {
                throw new GenericNotFoundException("Processor not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(processors), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<Processor>>> filterByPrice(Double min, Double max) {
        try {
            List<Processor> processors = dao.findAll().stream().filter(processor ->
                    processor.getPrice() >= min && processor.getPrice() <= max).toList();
            if (processors.isEmpty()) {
                throw new GenericNotFoundException("Processor not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(processors), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }

    public ResponseEntity<DataDTO<List<Processor>>> findByWidthAndHeight(Double width, Double height) {
        try {
            List<Processor> processors = dao.findAll().stream().filter(processor ->
                    processor.getWidth().equals(width) && processor.getHeight().equals(height)).toList();
            if (processors.isEmpty()) {
                throw new GenericNotFoundException("Processor not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(processors), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(AppErrorDTO.builder()
                    .friendlyMessage(e.getMessage())
                    .developerMessage(e.getMessage())
                    .build()), 400);
        }
    }
}
