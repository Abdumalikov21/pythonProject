package com.company.dao;

import com.company.config.CustomFileReader;
import com.company.domain.Processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProcessorDao implements BaseDao<Processor> {

    private final String processorFile = "src/main/resources/processor.csv";

    private final CustomFileReader fileReader = new CustomFileReader();

    @Override
    public List<Processor> findAll() throws IOException {
        return readKeyboardFile();
    }

    public List<Processor> readKeyboardFile() throws IOException {
        List<Processor> processors = new ArrayList<>();
        List<String> strings = fileReader.readFile(processorFile);
        strings.forEach(s -> processors.add(toKeyboard(s)));
        return processors;
    }

    private Processor toKeyboard(String line) {
        String[] strings = line.split(",");
        return Processor.childBuilder()
                .id(Long.valueOf(strings[0]))
                .color(strings[1])
                .price(Double.valueOf(strings[2]))
                .quantity(Integer.valueOf(strings[3]))
                .width(Double.valueOf(strings[4]))
                .height(Double.valueOf(strings[5]))
                .build();
    }
}
