package com.company.dao;

import com.company.config.CustomFileReader;
import com.company.domain.Internet_Cabel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InternetCabelDao implements BaseDao<Internet_Cabel> {

    private final String internetCable = "src/main/resources/internet_cabel.csv";

    private final CustomFileReader fileReader = new CustomFileReader();

    @Override
    public List<Internet_Cabel> findAll() throws IOException {
        return readMouseFile();
    }

    public List<Internet_Cabel> readMouseFile() throws IOException {
        List<Internet_Cabel> internetCables = new ArrayList<>();
        List<String> strings = fileReader.readFile(internetCable);
        strings.forEach(s -> internetCables.add(toMouse(s)));
        return internetCables;
    }

    private Internet_Cabel toMouse(String line) {
        String[] strings = line.split(",");
        return Internet_Cabel.childBuilder()
                .id(Long.valueOf(strings[0]))
                .color(strings[1])
                .price(Double.valueOf(strings[2]))
                .quantity(Integer.valueOf(strings[3]))
                .wireless(Boolean.valueOf(strings[4]))
                .length(Double.valueOf(strings[5]))
                .build();
    }
}
