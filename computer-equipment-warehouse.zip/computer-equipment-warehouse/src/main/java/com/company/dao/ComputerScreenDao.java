package com.company.dao;

import com.company.config.CustomFileReader;
import com.company.domain.ComputerScreen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ComputerScreenDao implements BaseDao<ComputerScreen> {

    private final String computerScreenFile = "src/main/resources/computerscreen.csv";

    private final CustomFileReader fileReader = new CustomFileReader();

    @Override
    public List<ComputerScreen> findAll() throws IOException {
        return readMonitorFile();
    }

    public List<ComputerScreen> readMonitorFile() throws IOException {
        List<ComputerScreen> computerScreens = new ArrayList<>();
        List<String> strings = fileReader.readFile(computerScreenFile);
        strings.forEach(s -> computerScreens.add(toMonitor(s)));
        return computerScreens;
    }

    private ComputerScreen toMonitor(String line) {
        String[] strings = line.split(",");
        return ComputerScreen.childBuilder()
                .id(Long.valueOf(strings[0]))
                .color(strings[1])
                .price(Double.valueOf(strings[2]))
                .quantity(Integer.valueOf(strings[3]))
                .refreshRate(Integer.valueOf(strings[4]))
                .displaySize(Integer.valueOf(strings[5]))
                .company(strings[6])
                .build();
    }
}
