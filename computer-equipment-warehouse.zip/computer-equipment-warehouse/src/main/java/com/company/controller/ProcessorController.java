package com.company.controller;

import com.company.domain.Processor;
import com.company.dtos.DataDTO;
import com.company.dtos.ResponseEntity;
import com.company.service.ProcessorService;
import com.company.utils.BaseUtils;

import java.util.List;

public class ProcessorController implements BaseController {

    private final ProcessorService service = new ProcessorService();

    @Override
    public void showAll(String sort) {
        ResponseEntity<DataDTO<List<Processor>>> responseEntity = service.findAll(sort);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByID() {
        BaseUtils.print("Enter id: ");
        ResponseEntity<DataDTO<Processor>> responseEntity = service.findByID(BaseUtils.readLong());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByColor() {
        BaseUtils.print("Enter color: ");
        ResponseEntity<DataDTO<List<Processor>>> responseEntity = service.findByColor(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void filterByPrice() {
        BaseUtils.print("Enter min: ");
        Double min = BaseUtils.readDouble();
        BaseUtils.print("Enter max: ");
        Double max = BaseUtils.readDouble();
        ResponseEntity<DataDTO<List<Processor>>> responseEntity = service.filterByPrice(min, max);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findByWidthAndHeight() {
        BaseUtils.print("Enter width: ");
        Double width = BaseUtils.readDouble();
        BaseUtils.print("Enter height: ");
        Double height = BaseUtils.readDouble();
        ResponseEntity<DataDTO<List<Processor>>> responseEntity = service.findByWidthAndHeight(width, height);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }
}
