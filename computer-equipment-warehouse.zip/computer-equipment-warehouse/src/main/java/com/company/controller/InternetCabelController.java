package com.company.controller;

import com.company.domain.Internet_Cabel;
import com.company.dtos.DataDTO;
import com.company.dtos.ResponseEntity;
import com.company.service.InternetCabelService;
import com.company.utils.BaseUtils;

import java.util.List;

public class InternetCabelController implements BaseController {

    private final InternetCabelService service = new InternetCabelService();

    @Override
    public void showAll(String sort) {
        ResponseEntity<DataDTO<List<Internet_Cabel>>> responseEntity = service.findAll(sort);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByID() {
        BaseUtils.print("Enter id: ");
        ResponseEntity<DataDTO<Internet_Cabel>> responseEntity = service.findByID(BaseUtils.readLong());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByColor() {
        BaseUtils.print("Enter color: ");
        ResponseEntity<DataDTO<List<Internet_Cabel>>> responseEntity = service.findByColor(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void filterByPrice() {
        BaseUtils.print("Enter min: ");
        Double min = BaseUtils.readDouble();
        BaseUtils.print("Enter max: ");
        Double max = BaseUtils.readDouble();
        ResponseEntity<DataDTO<List<Internet_Cabel>>> responseEntity = service.filterByPrice(min, max);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findByWireLess() {
        BaseUtils.print("Want wireless (yes/no) : ");
        ResponseEntity<DataDTO<List<Internet_Cabel>>> responseEntity = service.findByWireLess(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }
}
