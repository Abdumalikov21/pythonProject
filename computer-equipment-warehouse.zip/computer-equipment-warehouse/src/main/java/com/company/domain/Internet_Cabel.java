package com.company.domain;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Internet_Cabel extends BaseDomain {
    private Boolean wireless;
    private Double length;

    @Builder(builderMethodName = "childBuilder")
    public Internet_Cabel(Long id, String color, Double price, Integer quantity,
                          Boolean wireless, Double length) {
        super(id, color, price, quantity);
        this.wireless = wireless;
        this.length = length;
    }
}
