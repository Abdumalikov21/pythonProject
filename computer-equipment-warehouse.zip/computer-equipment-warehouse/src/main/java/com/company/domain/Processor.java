package com.company.domain;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Processor extends BaseDomain {
    private Double width;
    private Double height;

    @Builder(builderMethodName = "childBuilder")
    public Processor(Long id, String color, Double price, Integer quantity,Double width, Double height) {
        super(id, color, price, quantity);
        this.width = width;
        this.height = height;
    }
}
