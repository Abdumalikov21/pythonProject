package com.company.ui;

import com.company.controller.ProcessorController;
import com.company.controller.ComputerScreenController;
import com.company.controller.InternetCabelController;
import com.company.utils.BaseUtils;

import java.util.Objects;

public class AppUI {

    private final ComputerScreenController computerScreenController = new ComputerScreenController();
    private final ProcessorController processorController = new ProcessorController();
    private final InternetCabelController internetCabelController = new InternetCabelController();

    public void run() {
        BaseUtils.println("\n\n1 -> ComputerScreen");
        BaseUtils.println("2 -> Processor");
        BaseUtils.println("3 -> InternetCable");
        BaseUtils.println("q -> Quit");

        BaseUtils.print("-- Select operation: ");
        switch (BaseUtils.readText()) {
            case "1" -> computer_screenUI();
            case "2" -> processorUI();
            case "3" -> internet_cableUI();
            case "q" -> System.exit(0);
            default -> BaseUtils.println("Wrong choice!");
        }
        run();
    }

    public String baseUI() {
        BaseUtils.println("1 -> Show all");
        BaseUtils.println("2 -> Find by id");
        BaseUtils.println("3 -> Find by color");
        BaseUtils.println("4 -> Filter by price");
        BaseUtils.println("0 -> Back");

        BaseUtils.print("Select operation: ");
        return BaseUtils.readText();
    }

    private void computer_screenUI() {
        BaseUtils.println("\n\n5 -> Find by refresh rate");
        BaseUtils.println("6 -> Find by display size");
        switch (baseUI()) {
            case "1" -> showAllComputerScreen();
            case "2" -> computerScreenController.findByID();
            case "3" -> computerScreenController.findByColor();
            case "4" -> computerScreenController.filterByPrice();
            case "5" -> computerScreenController.refreshRate();
            case "6" -> computerScreenController.displaySize();
            case "0" -> run();
            default -> BaseUtils.println("Wrong choice!");
        }
        computer_screenUI();
    }

    private String showUI() {
        BaseUtils.println("\n\n1 -> Sort by id");
        BaseUtils.println("2 -> Sort by price");
        BaseUtils.println("0 -> Back");

        BaseUtils.print("-- Select operation: ");
        return BaseUtils.readText();
    }

    private void showAllComputerScreen() {
        String operation = showUI();
        if (Objects.equals(operation, "0")) {
            computer_screenUI();
        }
        computerScreenController.showAll(operation);
        showAllComputerScreen();
    }

    private void processorUI() {
        BaseUtils.println("\n\n5 -> Find by width and height");
        switch (baseUI()) {
            case "1" -> showAllProcessor();
            case "2" -> processorController.findByID();
            case "3" -> processorController.findByColor();
            case "4" -> processorController.filterByPrice();
            case "5" -> processorController.findByWidthAndHeight();
            case "0" -> run();
            default -> BaseUtils.println("Wrong choice!");
        }
        processorUI();
    }

    private void showAllProcessor() {
        String operation = showUI();
        if (Objects.equals(operation, "0")) {
            processorUI();
        }
        processorController.showAll(operation);
        showAllProcessor();
    }

    private void internet_cableUI() {
        BaseUtils.println("\n\n5 -> Find by wireless");
        switch (baseUI()) {
            case "1" -> showAllInternetCable();
            case "2" -> internetCabelController.findByID();
            case "3" -> internetCabelController.findByColor();
            case "4" -> internetCabelController.filterByPrice();
            case "5" -> internetCabelController.findByWireLess();
            case "0" -> run();
            default -> BaseUtils.println("Wrong choice!");
        }
        internet_cableUI();
    }

    private void showAllInternetCable() {
        String operation = showUI();
        if (Objects.equals(operation, "0")) {
            internet_cableUI();
        }
        internetCabelController.showAll(operation);
        showAllInternetCable();
    }
}
