package com.company;

import com.company.ui.AppUI;
import com.company.utils.BaseUtils;

public class Main {
    static AppUI appUI = new AppUI();

    public static void main(String[] args) {
        BaseUtils.println("\n\n*************** Project: Warehouse search system *****************");
        BaseUtils.println("--------------- Author: Abdumalikov Elbek ---------------");
        BaseUtils.println("--------------- Email: eabdumalikov150@gmail.com ---------------");
        BaseUtils.println("--------------- Creation date: since 04/06/23 17:12 ---------------");
        BaseUtils.println("--------------- Version: version-0.0.1 ---------------");
        appUI.run();
    }
}